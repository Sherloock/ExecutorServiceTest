futtatás:
1. open cmdline
2. open folder
3. run

example:
cd C:\Java\ExecuteorServicePrime\dist
java -jar "ExecuteorServicePrime.jar" 